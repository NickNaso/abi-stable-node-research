#include "gonapi.h"

#include "_cgo_export.h"


struct CallbackData {
  CallbackData(int data) : data{data} {}
  callback operator()() {
    static auto dataCopy = data;
    return [](int in) -> int {
        return dataCopy + in;
    };
  }
  int data;
};

/*struct CallbackData {
   static void printMessage() {
        printf("ACFunctionCallback()\n");
   }
};*/

void ACFunction() {
    printf("%d", (int)sum(10, 1));
	printf("%s"," ACFunction()\n");
    CallbackData cb{10};
    printf("%d", cb()(13));
	AGoFunction();
}


callback ACFunctionPointer() {
    CallbackData cb{10};
    return cb();
}

void Call(callback fn) {
    printf("%d", fn(10));
}