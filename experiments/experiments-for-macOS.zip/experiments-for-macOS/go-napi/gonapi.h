#ifndef GO_NAPI_H
#define GO_NAPI_H

#include <sum.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*callback)(int in);
extern void Call(callback fn);
extern callback ACFunctionPointer();
extern void ACFunction();

#ifdef __cplusplus
}  // extern "C"
#endif

#endif  // GO_NAPI_H