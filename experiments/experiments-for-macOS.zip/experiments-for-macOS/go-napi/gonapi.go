package main

/*
#cgo CXXFLAGS: -std=c++11
#cgo CXXFLAGS:  -I./include/
#cgo CFLAGS: -I./include/
#cgo LDFLAGS: -L./lib/ -lsumstub
#include <stdio.h>
#include "gonapi.h"
#include <sum.h>
*/
import "C"
import (
	"fmt"
)


//export AGoFunction
func AGoFunction() {
	fmt.Println("AGoFunction() ", C.sum(C.double(10), C.double(1)))
	C.Call(C.ACFunctionPointer())
}

//export Example
func Example() {
	C.ACFunction()
}

func main () {}
