#include "sum.h"

double sum(double a, double b) {
    double value;
    return value;
}