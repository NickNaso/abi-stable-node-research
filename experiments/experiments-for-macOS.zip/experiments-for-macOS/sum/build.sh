#!/bin/bash 

echo Starting build process ...  && \

echo Cleanup previous build ... && \
rm -rf *.o && \
rm -rf *.a && \
echo Cleanup process completed. && \

echo Build C library ...  && \

gcc -c sum.c && \
ar -rcs libsum.a sum.o && \
ranlib libsum.a && \

gcc -c sum-stub.c && \
ar -rcs libsumstub.a sum-stub.o && \
ranlib libsumstub.a && \

echo C library successfully builded.