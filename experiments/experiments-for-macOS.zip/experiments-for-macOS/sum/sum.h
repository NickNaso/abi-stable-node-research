#ifndef _SUM_H
#define _SUM_H

#ifdef __cplusplus 
extern "C" {
#endif
  
extern double sum(double a, double b);
    
#ifdef __cplusplus 
}
#endif

#endif