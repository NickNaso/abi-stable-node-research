#include "sum.h"

double sum(double a, double b) {
    return a + b;
}